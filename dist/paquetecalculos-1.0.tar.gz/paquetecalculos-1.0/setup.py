from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Juan",
    author_email="juanf.vazquez@hotmail.com",
    url="www.pildorasinformaticas.es",
    packages=["calculos", "calculos.redondeo_potencia"]

)