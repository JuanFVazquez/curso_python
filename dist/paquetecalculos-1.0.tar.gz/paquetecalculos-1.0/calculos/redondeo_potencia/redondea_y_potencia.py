def potencia(base, exponente):
    return base ** exponente
    
def redondear(a):
    return round(a)